package pv_admin;

public class admin_page_repository {

	static final String url_admin="https://qapoc.sgligis.com:10014/";
	static final String hamburgermenu="//div[@class='lp-toggle-sidebar']";
	static final String logo_leftpane="//a[@class='logo']";
	static final String opt_home="//span[contains(text(),'Home')]";
	static final String opt_map="//nav[@role='navigation']/ul/li[2]//span[contains(text(),'Map')]";
	static final String opt_dashboard="//span[contains(text(),'Dashboard')]";
	static final String opt_saas="//span[contains(text(),'Saas')]";
	static final String opt_CMS="//span[contains(text(),'CMS')]";
	static final String opt_administration="//span[contains(text(),'Administration')]";
	static final String opt_resourcetype="//span[contains(text(),'Resource Type')]";
	static final String opt_FIRs="//span[contains(text(),'FIRs')]";
	static final String opt_FileManagement="//span[contains(text(),'File Management')]";
	static final String opt_forms="//span[contains(text(),'Forms')]";
	static final String opt_LayerManagement="//span[contains(text(),'Layer Management')]";
	static final String opt_UserManagement="//span[contains(text(),'User Management')]";
	static final String opt_masters="//span[contains(text(),'Masters')]";
	static final String opt_crimemapping="//span[contains(text(),'Crime Mapping')]";
	static final String opt_AppSettings="//span[contains(text(),'Application Settings')]";
	static final String opt_patrollings="//span[contains(text(),'Patrollings')]";
	static final String opt_DatabaseConfing="//span[contains(text(),'Database Configurator')]";
	
	
}
