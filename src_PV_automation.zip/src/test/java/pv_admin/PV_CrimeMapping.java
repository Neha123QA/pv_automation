package pv_admin;

import static org.testng.Assert.assertEquals;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Coordinates;
import org.openqa.selenium.interactions.Locatable;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.model.Log;

import Listener.ExtentTestManager;
import Listener.Screenshot_extra;
import io.github.bonigarcia.wdm.WebDriverManager;

public class PV_CrimeMapping {
	WebDriver driver;
	Screenshot_extra ll=new Screenshot_extra();
	String i="PV_CrimeMapping_extra_ss";
	FirefoxProfile geoenabled = new FirefoxProfile();
	
	@BeforeClass
	public void setDriver(ITestContext context) throws InterruptedException
	{
		//System.setProperty("webdriver.gecko.driver", "D:\\Selenium\\GeckoDriver\\geckodriver.exe");
		//driver=new FirefoxDriver();

	}
	
	
	@BeforeMethod
	@Test
	public void Openurl(ITestContext context) throws InterruptedException, MalformedURLException 
	{
		
		System.setProperty("webdriver.gecko.driver", "D:\\Selenium\\GeckoDriver\\geckodriver.exe");
		//driver=new FirefoxDriver();
		
		  //WebDriverManager.chromedriver().setup();
		/*
		  FirefoxOptions options = new FirefoxOptions();
	      Map<String, Object> prefs = new HashMap<String, Object>();
	      prefs.put("profile.default_content_setting_values.geolocation", 1);
	      options.setCapability("prefs", prefs);
		  driver = new FirefoxDriver(options);
		  context.setAttribute("WebDriver", driver);
		  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		  driver.manage().window().maximize();
		  driver.manage().getCookies();
		  */
		
		
		geoenabled.setPreference("geo.enabled", true);
		geoenabled.setPreference("geo.provider.use_corelocation", true);
		geoenabled.setPreference("geo.prompt.testing", true);
		geoenabled.setPreference("geo.prompt.testing.allow", true);
		geoenabled.setPreference("security.mixed_content.block_active_content",false);
		geoenabled.setPreference("security.mixed_content.block_display_content",true);
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability(FirefoxDriver.PROFILE, geoenabled);
		driver = new FirefoxDriver(capabilities);
		
		
		//WebDriverManager.chromedriver().setup();
		//driver=new ChromeDriver();
		  context.setAttribute("WebDriver", driver);
		  Thread.sleep(2000);
		  driver.manage().window().maximize();
		  driver.manage().deleteAllCookies();
		
		driver.get("http://pvqaadmin.sgligis.com");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(By.xpath(Login_repository.btn_Login)).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(Login_repository.txtbox_Username)).sendKeys("Admin");
		Thread.sleep(1000);
		driver.findElement(By.xpath(Login_repository.txtbox_Password)).sendKeys("1q2w3E*");
		Thread.sleep(1000);
		driver.findElement(By.xpath(Login_repository.btn_Login1)).click();
		Thread.sleep(5000);
	}
	
	
	@Test(priority=0,description="To verify that user is able to expand/collapse \"Crime Mapping\" menu from left panel of police vertical web portal.")
	public void PV_CrimeMapping_01(Method method) throws InterruptedException
	{
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Home");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		String a1=driver.findElement(By.xpath(CrimeMapping_repository.style_exp_coll)).getAttribute("style");
		System.out.println(a1);
		Thread.sleep(1000);
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mapping\" menu from left pane.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get \"Crime Mapping\" in expanded mode with following :</br>"
				+ "1. Crimes</br>"
				+ "2. Crime Types</br>"
				+ "3. Crime Analysis"));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Crime Mapping\" menu from left panel.");
		String a2=driver.findElement(By.xpath(CrimeMapping_repository.style_exp_coll)).getAttribute("style");
		System.out.println(a2);
		Thread.sleep(1000);
		Assert.assertNotEquals(a1, a2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should get \"Crime Mapping\" in collapse mode."));
	}
	
	@Test(priority=2,description="To verify that user is able to get \"Crimes\" page.")
	public void PV_CrimeMapping_02() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(),"Crimes");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_Actions)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_recordno)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetype)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_summary)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_jurisdiction)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_reportingtime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_severity)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_creationtime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_creatorname)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_lastmodificationtime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_lastmodifiername)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_next)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_previous)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_entries)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>>> User should get \"Crimes\" page with following :</br>"
				+ "1. Buttons : \"Register Crime\" , \"Next\" , \"Previous\" ,  Page Control Numbers.</br>"
				+ "2. Text-box : \"SEARCH\".</br>"
				+ "3. Table of added crime list with following column fields :</br>"
				+ "\"Actions\" , \"Record No\" , \"Crime Type\" ,\"Summary\" , Jurisdiction\" , \"Crime Time\", \"Reporting Time\",\"Severity\" , \"Creation Time\" , \"CreatorName(BadgeNo)\" , \"Last Modification Time\" , \"LastModifierName(BadgeNo).</br>"
				+ "4. Dropdown : \"Actions\" button ,\"Show entries\" .</br>"
				+ "5. Links : \"Home\" icon.\r\n"
				+ "</br>"
				+ ">> User should get \"Crimes\" page with list of crimes If added otherwise displays No data available."));
	}

	
	@Test(priority=2,description="To verify that user is able to get back to \"Home\" page from \"Crimes\" page by clicking on \"Home\" icon.")
	public void PV_CrimeMapping_03() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(),"Crimes");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_Home)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Home\" icon from \"Users\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(),"Home");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get back to \"Home\" page from \"Crimes\" page."));
	}
	
	@Test(priority=3,description="To verify that user is able to perform Pagination functionality of \"Crimes\" page.")
	public void PV_CrimeMapping_04(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		System.out.println(s1);
		String[] b=s1.split(" "); 
		String c= b[5]; 
		System.out.println(c);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_next)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Next\" button of the paging.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 11 to 20 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get next page record list of \"Crimes\" page."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		
		driver.findElement(By.xpath(CrimeMapping_repository.btn_previous)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Previous\" button of the paging.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to 10 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should get previous page record list of \"Crimes\" page."));
		ll.Screenshotnew(driver,i,method.getName()+"_02");
		
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_pageno_3)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on particular page no. in \"Crimes\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 21 to 30 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_3</b> : User should get selected page no. record list of \"Crimes\" page ."));
	}
	
	@Test(priority=4,description="To verify that user is able to perform \"SEARCH\" functionality of \"Crimes\" page.")
	public void PV_CrimeMapping_05() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("1886");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Enter search criteria into \"SEARCH\" text-box.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_first)).getText(), "1886");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to 1 of 1 entries");
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get the searched result in \"Crimes\" page."));
	}
	
	@Test(priority=5,description="To verify that user is able to perform \"Show No. of entries\" functionality from \"Crimes\" page.")
	public void PV_CrimeMapping_06() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		System.out.println(s1);
		String[] b=s1.split(" "); 
		String c= b[5];
		driver.findElement(By.xpath(CrimeMapping_repository.dd_entries)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.entries_25)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Select number from the \"Show No. of entries\" dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to 25 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get records as per selected number of entries in \"Crimes\" page."));
	}
	
	@Test(priority=6,description="To verify that user is able to perform sorting functionality of columns from \"Crimes\" page.")
	public void PV_CrimeMapping_07(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_recordno)).click();
		Thread.sleep(1000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_recordno)).getAttribute("aria-sort");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_recordno)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on sorting icon of the \"Record No\" column.");
		String s2=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_recordno)).getAttribute("aria-sort");
		Assert.assertNotEquals(s1, s2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get records in numerical sorting order of \"Record No\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetype)).click();
		Thread.sleep(1000);
		String s3=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetype)).getAttribute("aria-sort");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetype)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on sorting icon of the \"Crime Type\" column.");
		String s4=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetype)).getAttribute("aria-sort");
		Assert.assertNotEquals(s3, s4);
		
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should get records in alphabetical sorting order of \"Crime Type\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_02");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_summary)).click();
		Thread.sleep(1000);
		String s5=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_summary)).getAttribute("aria-sort");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_summary)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on sorting icon of the \"Summary\" column.");
		String s6=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_summary)).getAttribute("aria-sort");
		Assert.assertNotEquals(s5, s6);
		
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_3</b> : User should get records in alphabetical sorting order of \"Summary\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_03");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_jurisdiction)).click();
		Thread.sleep(1000);
		String s7=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_jurisdiction)).getAttribute("aria-label");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_jurisdiction)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on sorting icon of the \"Jurisdiction\" column.");
		String s8=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_jurisdiction)).getAttribute("aria-label");
		Assert.assertNotEquals(s7, s8);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_4</b> : User should get records in alphabetical sorting order of \"Jurisdiction\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_04");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetime)).click();
		Thread.sleep(1000);
		String t1=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetime)).getAttribute("aria-label");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on sorting icon of the \"Crime Time\" column.");
		String t2=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_crimetime)).getAttribute("aria-label");
		Assert.assertNotEquals(t1, t2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_5</b> : User should get records in sorting order of \"Crime Time\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_05");
		
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_reportingtime)).click();
		Thread.sleep(1000);
		String t3=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_reportingtime)).getAttribute("aria-label");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_reportingtime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on sorting icon of the \"Reporting Time\" column.");
		String t4=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_reportingtime)).getAttribute("aria-label");
		Assert.assertNotEquals(t3, t4);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_6</b> : User should get records in sorting order of \"Reporting Time\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_06");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_severity)).click();
		Thread.sleep(1000);
		String t5=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_severity)).getAttribute("aria-label");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_severity)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on sorting icon of the \"Severity\" column.");
		String t6=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_severity)).getAttribute("aria-label");
		Assert.assertNotEquals(t5, t6);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_7</b> : User should get records in sorting order of \"Severity\" data fields."));
	}
	
	@Test(priority=7,description="To verify that user is able to get \"Register Crime\" page by performing \"Register Crime\" functionality from \"Crimes\" page.")
	public void PV_CrimeMapping_08() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.repoTime_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_FIRno)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_Fileno)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should get message popup for location access.</br>"
				+ "2. User should get \"Register Crime\" page with two sections : Window section(For create new crime) , Map.</br>"
				+ "3. Window section contains following : </br>"
				+ "3.1. Dropdowns: \"Select Location\", \"Select Crime\",\"Severity\".</br>"
				+ "3.2. Text-boxes : \"Latitude\" , \"Longitude\" ,\"Summary\" , \"Description\" , \"Crime Time\", \"Crime End Time\" , \"Reporting Time\",\"FIR No\", \"File No\".</br>"
				+ "3.3. Buttons : \"Cancel\" ,\"Save\" , \"Update & Continue\" .</br>"
				+ "4. Map contains following :</br>"
				+ "Icon Buttons : Kebab Menu (3 vertical dot) ,\"Hamburger menu\"."));
	}
	
	@Test(priority=8,description="To verify that user is able to get back to \"Home\" page from \"Register Crime\" page by clicking on \"Home\" icon.")
	public void PV_CrimeMapping_09() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_Home)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Home\" icon from \"Register Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(),"Home");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get back to \"Home\" page from \"Register Crime\" page."));
	}
	
	@Test(priority=9,description="To verify that user is able to register new crime by performing \"Register Crime\" functionality with selection of \"Current Location\" option.")
	public void PV_CrimeMapping_10(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Murder");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select type of crime from \"Select Crime\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("High");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Select Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select Crime Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select Crime End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).sendKeys("This is Test1.");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter Crime Incident Summary in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).sendKeys("Test Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Enter Crime description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_registercrime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Save\" button from \"Register Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "Your crime has been successfully registered.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : </br>1. User should able to click on \"Save\" button from \"Register Crime\" page.</br>"
				+ "2. User should get validation message like \"Your crime has been successfully registered.\r\n"
				+ "Record Number : x\"."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crimes");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test1.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime)).getText(), "This is Test1.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should redirect back to listing of \"Crimes\" page by clicking on \"OK\" button of validation message popup.</br>"
				+ "2. Added crime should display in list of \"Crimes\" page."));
	}
	
	@Test(priority=10,description="To verify that user is able to register new crime by performing \"Register Crime\" functionality with selection of \"Enter Coordinates\" option.")
	public void PV_CrimeMapping_11(Method method) throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Murder");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select type of crime from \"Select Crime\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("High");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Select Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).sendKeys("Enter Coordinates");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select \"Enter Coordinates\" option from \"Select Location\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long)).sendKeys("72.544567");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Enter Longitude value in \"Longitude\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat)).sendKeys("23.028306");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter Latitude value in \"Latitude\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Select Crime Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Select Crime End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).sendKeys("This is Test2.");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Enter Crime Incident Summary in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).sendKeys("Test Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Enter Crime description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_registercrime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-17</b> : Click on \"Save\" button from \"Register Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "Your crime has been successfully registered.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button from \"Register Crime\" page.</br>"
				+ "2. User should get validation message like \"Your crime has been successfully registered.\r\n"
				+ "Record Number : x\"."));
		
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-18</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crimes");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime)).getText(), "This is Test2.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should redirect back to listing of \"Crimes\" page by clicking on \"OK\" button of validation message popup.</br>"
				+ "2. Added crime should display in list of \"Crimes\" page."));
	}
	
	@Test(priority=11,description="To verify that user is able to register new crime by performing \"Register Crime\" functionality with selection of \"Click on map\" option.")
	public void PV_CrimeMapping_12(Method method) throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Theft");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select type of crime from \"Select Crime\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("Moderate");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Select Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_home_map)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).sendKeys("Click On Map");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select \"Click on map\" option from \"Select Location\" dropdown.");
		WebElement el=driver.findElement(By.xpath(CrimeMapping_repository.img_map));
		int width = el.getSize().getWidth();
		Actions act = new Actions(driver);
		act.moveToElement(el);
		act.moveByOffset((width/4)-5,100).click().build().perform();
		//(width/2)-25
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click at any point of map.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Select Crime Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Select Crime End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).sendKeys("This is Test3.");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Enter Crime Incident Summary in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).sendKeys("Test Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Enter Crime description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_registercrime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Click on \"Save\" button from \"Register Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "Your crime has been successfully registered.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button from \"Register Crime\" page.</br>"
				+ "2. User should get validation message like \"Your crime has been successfully registered.\r\n"
				+ "Record Number : x\"."));
		
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-17</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crimes");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test3.");
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime)).getText(), "This is Test3.");
		
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should redirect back to listing of \"Crimes\" page by clicking on \"OK\" button of validation message popup.</br>"
				+ "2. Added crime should display in list of \"Crimes\" page."));
	}
	
	@Test(priority=12,description="To verify that user is able to perform \"Cancel\" functionality from \"Register Crime\" page.")
	public void PV_CrimeMapping_13() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Cancel\" button from \"Register Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crimes");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Cancel\" button.</br>"
				+ "2. User should redirect back to \"Crimes\" page."));
	}
	
	
	
	@Test(priority=13,description="To verify that user gets validation messages when perform \"Save\"/\"Save & Continue\" functionality of \"Register Crime\" page with selection of \"Current Location\" option and blank mandatory details.")
	public void PV_CrimeMapping_14() throws InterruptedException, MalformedURLException
	{
		/*
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		*/
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		//ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		//ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		
		
		//ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Allow\" button of message pop-up.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_registercrime)).click();
		Thread.sleep(1000);
		//ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Save\"/\"Update & Continue\" button from \"Register Crime\" page without entering mandatory details.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_summary_regcrime)).getText(), "The Summary field is required.");
		//ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get validation messages like :\r\n"
			//	+ "\"The Summary field is required.\" below respective field."));
	}
	
	@Test(priority=14,description="To verify that user gets validation messages when perform \"Save\"/\"Update & Continue\" functionality of \"Register Crime\" page with selection of \"Enter Coordinates\"/\"Click on map\" option and blank mandatory details.")
	public void PV_CrimeMapping_15() throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).sendKeys("Enter Coordinates");
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select \"Enter Coordinates\" option from \"Select Location\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_registercrime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Save\"/\"Update & Continue\" button from \"Register Crime\" page without entering mandatory details.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_summary_regcrime)).getText(), "The Summary field is required.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_long)).getText(), "The Longitude field is required.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_lat)).getText(), "The Latitude field is required.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get validation messages like :</br> \"The Longitude field is required.\", </br>\"The Latitude field is required.\", </br>\"The Summary field is required.\" below their respective fields."));
	}
	
	@Test(priority=15,description="To verify that user gets validation message when select invalid date or time for \"Crime Time\" from Date & Time Picker of \"Register Crime\" form.")
	public void PV_CrimeMapping_16(Method method) throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		
		
		Date dt = new Date(); 
		 
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(dt); 
		calendar.add(Calendar.DATE, 1); 
		dt = calendar.getTime(); 
		 
		String tommorowsDate = new SimpleDateFormat("MM/dd/yyyy").format(dt); 
		 
		//enter tomorrow's date in the field 
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		Thread.sleep(1000);
		WebElement tomDate = driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)); 
		tomDate.sendKeys(tommorowsDate); 
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).click();
		Thread.sleep(1000);
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select invalid \"Crime Time\" in \"Register Crime\" form.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "Start Date-Time Must Not Be Of Future");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : </br>1. User should able to select invalid \"Crime Time\" in \"Register Crime\" form. </br>2. User should get validation message like \"Start Date-Time Must Not Be Of Future\" below respective field."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should able to click on \"OK\" button of validation message popup and validation message popup should close."));
	}
	
	@Test(priority=16,description="To verify that user gets validation message when select invalid date or time for \"Crime End Time\" from Date & Time Picker of \"Register Crime\" form.")
	public void PV_CrimeMapping_17(Method method) throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		
		
		Date dt = new Date(); 
		 
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(dt); 
		calendar.add(Calendar.DATE, 1); 
		dt = calendar.getTime(); 
		 
		String tommorowsDate = new SimpleDateFormat("MM/dd/yyyy").format(dt); 
		 
		//enter tomorrow's date in the field 
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		Thread.sleep(1000);
		WebElement tomDate = driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)); 
		tomDate.sendKeys(tommorowsDate);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).click();
		Thread.sleep(1000);
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select invalid \"Crime End Time\" in \"Register Crime\" form.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "End Date-Time Must Not Be Of Future");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : </br>1. User should able to select invalid \"Crime End Time\" in \"Register Crime\" form. </br>2. User should get validation message like \"End Date-Time Must Not Be Of Future\" below respective field."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should able to click on \"OK\" button of validation message popup and validation message popup should close."));
	}
	
	@Test(priority=17,description="To verify that user gets validation message when End Crime Date is earlier than Start Crime Date.")
	public void PV_CrimeMapping_18(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		
		
		Date dt = new Date(); 
		 
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(dt); 
		calendar.roll(Calendar.DATE, -1); 
		dt = calendar.getTime(); 
		 
		String tommorowsDate = new SimpleDateFormat("MM/dd/yyyy").format(dt); 
		 
		//enter tomorrow's date in the field 
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		Thread.sleep(1000);
		WebElement tomDate = driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)); 
		tomDate.sendKeys(tommorowsDate);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).click();
		Thread.sleep(1000);
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select End Crime Date is earlier than Start Crime Date.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "End Date-Time Must Not Be Earlier Than Start Date-Time");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get validation message like \"End Date-Time Must Not Be Earlier Than Start Date-Time\"."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should able to click on \"OK\" button of validation message popup and validation message popup should close."));
	}
	
	@Test(priority=18,description="To verify that user gets validation message when select invalid date or time for \"Reporting Time\" from Date & Time Picker of \"Register Crime\" form.")
	public void PV_CrimeMapping_19(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		
		
		Date dt = new Date(); 
		 
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(dt); 
		calendar.add(Calendar.DATE, 1); 
		dt = calendar.getTime(); 
		 
		String tommorowsDate = new SimpleDateFormat("MM/dd/yyyy").format(dt); 
		 
		//enter tomorrow's date in the field 
		driver.findElement(By.xpath(CrimeMapping_repository.repoTime_crime)).clear();
		Thread.sleep(1000);
		WebElement tomDate = driver.findElement(By.xpath(CrimeMapping_repository.repoTime_crime)); 
		tomDate.sendKeys(tommorowsDate);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long)).click();
		Thread.sleep(1000);
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select invalid \"Reporting Time\" in \"Register Crime\" form.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "Reporting Time Must Not Be Of Future");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get validation message like \"Reporting Time Must Not Be Of Future\" below respective field."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should able to click on \"OK\" button of validation message popup and validation message popup should close."));
	}
	
	@Test()
	public void PV_CrimeMapping_20() throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		//ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		//ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		
		//FirefoxProfile geoenabled = new FirefoxProfile();
		/*
		geoenabled.setPreference("geo.enabled", false);
		geoenabled.setPreference("geo.provider.use_corelocation", false);
		geoenabled.setPreference("geo.prompt.testing", false);
		geoenabled.setPreference("geo.prompt.testing.allow", false);
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability(FirefoxDriver.PROFILE, geoenabled);
		*/
		
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setBrowserName("firefox");
		caps.setCapability("locationContextEnabled", false);
		

		
		//driver = new FirefoxDriver(capabilities);
		//WebDriver driver = new RemoteWebDriver(DesiredCapabilities.FirefoxDriver(capabilities));
		
		//ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Allow\" button of message pop-up.");
		
	}
	
	@Test(priority=20,description="To verify that user is able to get next screen of \"Register Crime\" form by performing \"Update & Continue\" functionality.")
	public void PV_CrimeMapping_21(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_registercrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Register Crime\" button.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Register Crime");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Auto Theft");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Select type of crime from \"Select Crime\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("Moderate");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Select Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_home_map)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).sendKeys("Click On Map");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select \"Click on map\" option from \"Select Location\" dropdown.");
		WebElement el=driver.findElement(By.xpath(CrimeMapping_repository.img_map));
		int width = el.getSize().getWidth();
		Actions act = new Actions(driver);
		act.moveToElement(el);
		act.moveByOffset((width/4)-5,100).click().build().perform();
		//(width/2)-25
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click at any point of map.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Select Crime Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Select Crime End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_FIRno)).sendKeys("198");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_Fileno)).sendKeys("69");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).sendKeys("This is Test3.");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Enter Crime Incident Summary in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).sendKeys("Test Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Enter Crime description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_continue_registercrime)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Click on \"Save & Continue\" button of \"Register Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "Your crime has been successfully registered.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should get validation message like \"Your crime has been successfully registered. Record Number : x\".</br>"
				+ "2. User should navigate to \"Crime Mappings\" page."));
		
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-17</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crime Mappings");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.header_crimeinfo)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.recordno_crimeinfo)).getText(), "Record No");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.fileno_crimeinfo)).getText(), "File No");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.firno_crimeinfo)).getText(), "FIR No");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.crimetime_crimeinfo)).getText(), "Crime Time");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.crimeendtime_crimeinfo)).getText(), "Crime End Time");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.reptime_crimeinfo)).getText(), "Reporting Time");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.severity_crimeinfo)).getText(), "Severity");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.summary_crimeinfo)).getText(), "Summary");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.des_crimeinfo)).getText(), "Description");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.investigationstatus_crimeinfo)).getText(), "Investigation Status");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.jurisdiction_crimeinfo)).getText(), "Jurisdiction");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.creatorname_crimeinfo)).getText(), "Creator Name (Badge No)");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.creationtime_crimeinfo)).getText(), "Creation Time");
		
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_map_crimemapp)).getAttribute("aria-selected"), "true");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_person_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_pp_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.img_map)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_tools)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_home_map)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_zoomin)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_zoomout)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should navigate to \"Crime Mappings\" page with following :</br>"
				+ "1. Crime Tree section with registered crime.</br>"
				+ "2. Tab sections : \"Map\" , \"Attachment\", \"Person\" , \"Police Person\".(By default \"Map\" tab is selected.</br>"
				+ "3. Button : \"<-Back\".</br>"
				+ "4. Text-box : \"Search\".</br>"
				+ "5. User should get \"Crime Information\" of saved crime with following details : </br>"
				+ "\"Record No\" , \r\n"
				+ "\"File No\" , \r\n"
				+ "\"FIR No\" ,\r\n"
				+ "\"Crime Time\"\r\n"
				+ "\"Crime End Time\" , \r\n"
				+ "\"Reporting Time\" ,\r\n"
				+ "\"Severity\" ,\r\n"
				+ "\"Summary\" ,\r\n"
				+ "\"Investigation Status\",\r\n"
				+ "\"Description\" ,\r\n"
				+ "\"Jurisdiction\",\r\n"
				+ "\"Creator Name\",\r\n"
				+ "\"Creation Time\"."));
		
	}
	
	@Test(priority=21,description="To verify that user is able to perform \"Crime Details\" functionality from \"Actions\" dropdown  of particular crime in \"Crimes\" page.")
	public void PV_CrimeMapping_22() throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test3.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crime Mappings");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.header_crimeinfo)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.recordno_crimeinfo)).getText(), "Record No");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.fileno_crimeinfo)).getText(), "File No");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.firno_crimeinfo)).getText(), "FIR No");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.crimetime_crimeinfo)).getText(), "Crime Time");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.crimeendtime_crimeinfo)).getText(), "Crime End Time");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.reptime_crimeinfo)).getText(), "Reporting Time");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.severity_crimeinfo)).getText(), "Severity");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.summary_crimeinfo)).getText(), "Summary");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.des_crimeinfo)).getText(), "Description");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.investigationstatus_crimeinfo)).getText(), "Investigation Status");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.jurisdiction_crimeinfo)).getText(), "Jurisdiction");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.creatorname_crimeinfo)).getText(), "Creator Name (Badge No)");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.creationtime_crimeinfo)).getText(), "Creation Time");
		
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_map_crimemapp)).getAttribute("aria-selected"), "true");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_person_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_pp_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.img_map)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_tools)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_home_map)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_zoomin)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_zoomout)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should navigate to \"Crime Mappings\" page."));
	}
	
	@Test(priority=22,description="To verify that user is able to perform \"<-Back\" functionality from \"Crime Mappings\"page.")
	public void PV_CrimeMapping_23() throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test3.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crime Mappings");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_back)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"<- Back\" button from \"Crime Mapping\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crimes");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should redirect back to the \"Crimes\" page from \"Crime mappings\" page."));
	}
	
	@Test(priority=23,description="To verify that user gets dropdown list menu items by right clicking on saved crime from \"Crime Mappings\" page.")
	public void PV_CrimeMapping_26() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_editcrime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get dropdown list with following menu items :</br>"
				+ "\"Add Parson\" ,</br>"
				+ "\"Add Police Person\" ,</br>"
				+ "\"Add Attachment\" , </br>"
				+ "\"Edit Crime\",</br>"
				+ "\"Add Event\"."));
	}
	
	@Test(priority=24,description="To verify that user is able to get \"New Person\" window by performing \"Add Person\" functionality from dropdown list.")
	public void PV_CrimeMapping_27() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_category_newperson_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.searchbox_newperson_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_search_newperson_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_newperson_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get \"New Person\" window with following : </br>"
				+ "1. Dropdown : Search Category\".</br>"
				+ "2. Text-box : \"Search\".</br>"
				+ "3. Buttons : \"New Person\" , \"Cancel\", \"Save\" , close(\"X\") , Search icon button."));
		
	}
	
	@Test(priority=25,description="To verify that user is able to add new person in any particular saved crime by performing \"Add Person\" functionality from dropdown list.")
	public void PV_CrimeMapping_28(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_newperson_win)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"New Person\" button from \"New Person\" window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_searchpr_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_associatedtype_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_firstname_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_midname_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lastname_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_dob_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_age_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_gen_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_add1_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_state_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_dist_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_taluka_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_village_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_pin_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_phoneno_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_altphoneno_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_email_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_phydes_newpr_win)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_newpr_win)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get \"New Person\" detailed form window with following :</br>"
				+ "1. Text-boxes : \"First Name\" , \"Middle Name\" , \"Last Name\", \"Age\" , \"Address Line 1\" , \"Address Line 2\" , \"PIN Code \" , \"Phone Number 1\" , \"Phone Number 2 \" , \"Email Id\" , \"Physical Description\".</br>"
				+ "2. Dropdowns : \"Associated Type\" , \"Country\" , \"State\" , \"District\" , \"Taluka\" , \"Village\".</br>"
				+ "3. Date picker : \"Date Of Birth\"."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		
		driver.findElement(By.xpath(CrimeMapping_repository.dd_associatedtype_newpr_win)).sendKeys("Complainant");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select Associated Type\" from  respective dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_firstname_newpr_win)).sendKeys("Rahul");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter First name into \"First Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_midname_newpr_win)).sendKeys("Mohanbhai");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Enter Middle Name into \"Middle Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lastname_newpr_win)).sendKeys("Patel");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Enter Late Name into \"Last Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_age_newpr_win)).sendKeys("24");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Enter \"Age\" in respective field.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_gen_newpr_win)).sendKeys("Male");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Select \"Gender\" from respective dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_add1_newpr_win)).sendKeys("A/123 Nikunj park,Thaltej");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-17</b> : Enter address into \"Address Line 1\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_state_newpr_win)).sendKeys("Gujarat");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-18</b> : Select \"State\" from \"State\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_dist_newpr_win)).sendKeys("Ahmedabad");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-19</b> : Select \"District\" from \"District\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_pin_newpr_win)).sendKeys("380052");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-20</b> : Enter PIN Code into \"PIN Code\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_phoneno_newpr_win)).sendKeys("9999911111");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-21</b> : Enter Phone Number into \"Phone Number 2 \" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_altphoneno_newpr_win)).sendKeys("9999922222");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-22</b> : Enter alternate phone number into \"Phone Number 2\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_email_newpr_win)).sendKeys("rp@gmail.com");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-23</b> : Enter Email Id into \"Email Id\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_newpr_win)).sendKeys("C:\\Users\\neha.p\\Pictures\\user_image.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-24</b> : Upload file of person in \"Select image\" field.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-25</b> : Click on \"Save\" button of \"New Person\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size() != 0, false);
		driver.findElement(By.xpath(CrimeMapping_repository.tab_person_crimemapp)).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(CrimeMapping_repository.searchbox_personsec)).sendKeys("Rahul");
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_firstname_persec)).getText(), "Rahul");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"New Person\" window and window should close.</br>"
				+ "2. Added person should display in list of \"Person\" section of selected crime."));
	}
	
	@Test(priority=26,description="To verify that user is able to add existing person in any particular saved crime by performing \"Search\" functionality of \"New Person\" window.")
	public void PV_CrimeMapping_29() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_category_newperson_win)).sendKeys("Name");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select \"Search Category\" from respective dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.searchbox_newperson_win)).sendKeys("Jesal");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Enter search criteria into \"Search\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.icon_search_newperson_win)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on \"Search\" icon button.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_add_first)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Add\" button of person which want to add.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Save\" button of \"New Person\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size() != 0, false);
		driver.findElement(By.xpath(CrimeMapping_repository.tab_person_crimemapp)).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(CrimeMapping_repository.searchbox_personsec)).sendKeys("Jesal");
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_firstname_persec)).getText(), "Jesal");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"New Person\" window and window should close.</br>"
				+ "2. Added person should display in list of \"Person\" section of selected crime."));
	}
	
	@Test(priority=27,description="To verify that user is able to perform \"Search Person\" functionality from \"New Person\" detailed form window.")
	public void PV_CrimeMapping_30() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(3000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_category_newperson_win)).sendKeys("Name");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select \"Search Category\" from respective dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.searchbox_newperson_win)).sendKeys("Jesal");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Enter search criteria into \"Search\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.icon_search_newperson_win)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on \"Search\" icon button.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_add_first)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Add\" button of person which want to add.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_searchpr_newpr_win)).isDisplayed(), true);
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_searchpr_newpr_win)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Search Person\" button from \"New Person\" detailed form window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_searchpr_newpr_win)).isDisplayed(), false);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_category_newperson_win)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should redirect back to \"New Person\" search window."));
		
	}
	
	@Test(priority=28,description="To verify that user is able to perform pagination functionality of searched person list in \"New Person\" window.")
	public void PV_CrimeMapping_31(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.icon_search_newperson_win)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Search\" icon button.");
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		System.out.println(s1);
		String[] b=s1.split(" "); 
		String c= b[5]; 
		System.out.println(c);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_next)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Next\" button of the paging.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 11 to 20 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get next page records of persons in \"New Person\" window."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		
		driver.findElement(By.xpath(CrimeMapping_repository.btn_previous)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on \"Previous\" button of the paging.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to 10 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should get previous page records of persons in \"New Person\" window."));
		ll.Screenshotnew(driver,i,method.getName()+"_02");
		
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_pageno_3)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on particular page no. of person table list in \"New Person\" window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 21 to 30 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_3</b> : User should get particular page no. records of persons in \"New Person\" window."));
	}
	
	@Test(priority=29,description="To verify that user is able to perform show no. of entries functionality of searched person list in \"New Person\" window.")
	public void PV_CrimeMapping_32() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.icon_search_newperson_win)).click();
		Thread.sleep(8000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Search\" icon button.");
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		System.out.println(s1);
		String[] b=s1.split(" "); 
		String c= b[5]; 
		System.out.println(c);
		WebElement el1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries));
		Coordinates co1=((Locatable)el1).getCoordinates();
		co1.onPage();
		co1.inViewPort();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_entries)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.entries_25)).click();
		Thread.sleep(1000);
		
		Thread.sleep(3000);
		WebElement el2=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries));
		Coordinates co2=((Locatable)el2).getCoordinates();
		co2.onPage();
		co2.inViewPort();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select number from the \"Show No. of entries\" dropdown list.");
		String s2=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		Assert.assertNotEquals(s1, s2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get records as per selected number of entries in \"New Person\" window."));
	}
	
	@Test(priority=30,description="To verify that user is able to perform sorting functionality of columns present in searched person list of \"New Person\" window.")
	public void PV_CrimeMapping_33(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.icon_search_newperson_win)).click();
		Thread.sleep(8000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Search\" icon button.");
		driver.findElement(By.xpath(UserManagement_repository.col_lbl_firstname)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Sorting\" icon of the \"First Name\" column of \"New Person\" window.");
		String s1=driver.findElement(By.xpath(UserManagement_repository.col_lbl_firstname)).getAttribute("style");
		driver.findElement(By.xpath(UserManagement_repository.col_lbl_firstname)).click();
		Thread.sleep(2000);
		String s2=driver.findElement(By.xpath(UserManagement_repository.col_lbl_firstname)).getAttribute("style");
		Assert.assertNotEquals(s1, s2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get records in sorting order of \"First Name\" data field in \"New Peron\" window."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(UserManagement_repository.col_lbl_lastname)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on \"Sorting\" icon of the \"Last Name\" column of \"New Person\" window.");
		String s3=driver.findElement(By.xpath(UserManagement_repository.col_lbl_lastname)).getAttribute("style");
		driver.findElement(By.xpath(UserManagement_repository.col_lbl_lastname)).click();
		Thread.sleep(2000);
		String s4=driver.findElement(By.xpath(UserManagement_repository.col_lbl_lastname)).getAttribute("style");
		Assert.assertNotEquals(s3, s4);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should get records in sorting order of \"Last Name\" data field in \"New Peron\" window."));
		
	}
	
	@Test(priority=31,description="To verify that user is able to close \"New Person\" window.")
	public void PV_CrimeMapping_34() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).click();
		Thread.sleep(2000);
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"X\"(close)  button of \"New Person\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to close \"New Person\" window."));
	}
	
	@Test(priority=32,description="To verify that user is able to perform \"Cancel\" functionality of \"New Person\" window.")
	public void PV_CrimeMapping_35() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(2000);
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\"  button of \"New Person\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of \"New Person\" window and \"New Person\" window should close."));
	}
	
	@Test(priority=33,description="To verify that user gets validation message for add person in \"Person\" section which is already added for particular saved crime.")
	public void PV_CrimeMapping_36() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select \"Search Category\" from respective dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.searchbox_newperson_win)).sendKeys("Jesal");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Enter search criteria into \"Search\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.icon_search_newperson_win)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on \"Search\" icon button.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_add_first)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Add\" button of person which want to add.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.toast_msg)).getText(), "This person is already associated in the current record.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get toast validation like \"This person is already associated in the current record.\"."));
		
	}
	
	@Test(priority=34,description="To verify that user gets validation message when perform \"Cancel\" functionality after adding details in \"New Person\" window.")
	public void PV_CrimeMapping_37() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_newperson_win)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"New Person\" button from \"New Person\" window.");
		
		
		driver.findElement(By.xpath(CrimeMapping_repository.dd_associatedtype_newpr_win)).sendKeys("Complainant");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select Associated Type\" from  respective dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_firstname_newpr_win)).sendKeys("Rahul");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter First name into \"First Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_midname_newpr_win)).sendKeys("Mohanbhai");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Enter Middle Name into \"Middle Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lastname_newpr_win)).sendKeys("Patel");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Enter Late Name into \"Last Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_age_newpr_win)).sendKeys("24");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Enter \"Age\" in respective field.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_gen_newpr_win)).sendKeys("Male");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Select \"Gender\" from respective dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_add1_newpr_win)).sendKeys("A/123 Nikunj park,Thaltej");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-17</b> : Enter address into \"Address Line 1\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_state_newpr_win)).sendKeys("Gujarat");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-18</b> : Select \"State\" from \"State\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_dist_newpr_win)).sendKeys("Ahmedabad");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-19</b> : Select \"District\" from \"District\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_pin_newpr_win)).sendKeys("380052");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-20</b> : Enter PIN Code into \"PIN Code\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_phoneno_newpr_win)).sendKeys("9999911111");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-21</b> : Enter Phone Number into \"Phone Number 2 \" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_altphoneno_newpr_win)).sendKeys("9999922222");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-22</b> : Enter alternate phone number into \"Phone Number 2\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_email_newpr_win)).sendKeys("rp@gmail.com");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-23</b> : Enter Email Id into \"Email Id\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_newpr_win)).sendKeys("C:\\Users\\neha.p\\Pictures\\user_image.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-24</b> : Upload file of person in \"Select image\" field.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-25</b> : Click on \"Cancel\"  button of \"New Person\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-26</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Cancel\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"New Person\" window should close."));
	}
	
	@Test(priority=35,description="To verify that user is able to \"Cancel\" validation message for unsaved changes of \"New Person\" window.")
	public void PV_CrimeMapping_38() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Person\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Person");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_newperson_win)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"New Person\" button from \"New Person\" window.");
		
		
		driver.findElement(By.xpath(CrimeMapping_repository.dd_associatedtype_newpr_win)).sendKeys("Complainant");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select Associated Type\" from  respective dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_firstname_newpr_win)).sendKeys("Rahul");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter First name into \"First Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_midname_newpr_win)).sendKeys("Mohanbhai");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Enter Middle Name into \"Middle Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lastname_newpr_win)).sendKeys("Patel");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Enter Late Name into \"Last Name\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Click on \"Cancel\"  button of \"New Person\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-166</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Cancel\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"New Person\" window shouldn't close."));
	}
	
	@Test(priority=36,description="To verify that user is able to get \"Add Police Persons\" window by performing \"Add Police Person\" functionality from dropdown list.")
	public void PV_CrimeMapping_39() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		WebElement el1=driver.findElement(By.xpath(CrimeMapping_repository.btn_save1));
		Coordinates co1=((Locatable)el1).getCoordinates();
		co1.onPage();
		co1.inViewPort();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Add Police Personnels");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_save1)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.seach_txtbox_1st)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_next)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_previous)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_entries)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>User should get \"Add Police Persons\" window with following :</br>"
				+ "1. Buttons: \"Cancel\", \"Save\", \"X\", \"Next\", \"Previous\", page control button.</br>"
				+ "2. Dropdown: \"Show entries\".</br>"
				+ "3. Columns: \"Username\" , \"Badge Number\" , \"Designation\".</br>"
				+ "4. Checkboxes for select police persons. "));
	}
	
	@Test(priority=37,description="To verify that user is able to add police person in any particular saved crime by performing \"Add Police Person\" functionality from dropdown list.")
	public void PV_CrimeMapping_40() throws InterruptedException 
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.seach_txtbox_1st)).sendKeys("Madhav");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_firstname_pptable)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.seach_txtbox_1st)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.seach_txtbox_1st)).sendKeys("Hill");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_firstname_pptable)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select one or more police persons by selecting checkboxes from list of police persons available in \"Add Police Personnels\" window.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save1)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Save\" button of \"Add Police Personnels\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.tab_pp_crimemapp)).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_firstname_ppsec)).getText(), "Hill");
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to 2 of 2 entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"Add Police Personnels\" window.</br>"
				+ "2. Added police persons for selected crime should display in list of \"Police Personnel\" section of that crime."));
	}
	
	@Test(priority=38,description="To verify that user is able to close \"Add Police Personnels\" window.")
	public void PV_CrimeMapping_41() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).click();
		Thread.sleep(1000);
		
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"X\"(close) button of \"Add Police Personnels\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to close \"Add Police Personnels\" window."));
	}
	
	@Test(priority=39,description="To verify that user is able to perform \"Cancel\" functionality of \"Add Police Personnels\" window.")
	public void PV_CrimeMapping_42() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(1000);
		
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\" button of \"Add Police Personnels\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of \"Add Police Personnels\" window and \"Add Police Personnels\" window should close."));
	}
	
	@Test(priority=40,description="To verify that user is able to perform \"Search\" functionality of \"Add Police Personnels\" window.")
	public void PV_CrimeMapping_43() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.seach_txtbox_1st)).sendKeys("Megh");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Enter search criteria into \"Search\" text-box of \"Add Police Personnels\" window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_firstname_pptable)).getText(), "Megha");
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to 1 of 1 entries");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get searched result in \"Add Police Personnels\" window."));
	}
	
	
	@Test(priority=41,description="To verify that user is able to perform pagination functionality of \"Add Police Personnels\" window.")
	public void PV_CrimeMapping_44(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		System.out.println(s1);
		String[] b=s1.split(" "); 
		String c= b[5]; 
		System.out.println(c);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_next)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Next\" button of \"Add Police Personnels\" window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 11 to 20 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get next page records in \"Add Police Personnels\" window."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		
		driver.findElement(By.xpath(CrimeMapping_repository.btn_previous)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Previous\" button of \"Add Police Personnels\" window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to 10 of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should get previous page records in \"Add Police Personnels\" window."));
		ll.Screenshotnew(driver,i,method.getName()+"_02");
		
		String s2=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_pageno_3)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on particular page no. from \"Add Police Personnels\" window.");
		Assert.assertNotEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), s2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_3</b> : User should get selected page no. records in \"Add Police Personnels\" window."));
	}
	
	@Test(priority=42,description="To verify that user is able to perform Show No. of entries functionality of \"Add Police Personnels\" window.")
	public void PV_CrimeMapping_45() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		String[] b=s1.split(" "); 
		String c= b[5];
		
		driver.findElement(By.xpath(CrimeMapping_repository.dd_entries)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.entries_25)).click();
		Thread.sleep(1000);
		WebElement el1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries));
		Coordinates co1=((Locatable)el1).getCoordinates();
		co1.onPage();
		co1.inViewPort();
		Thread.sleep(1000);
		String s2=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		String[] b1=s2.split(" "); 
		String c1= b1[3];
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Select number from the \"Show No. of entries\" dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to "+ c1 +" of " + c + " entries");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get records as per selected number of entries in \"Add Police Personnels\" window."));
	}
	
	@Test(priority=43,description="To verify that user is able to perform sorting functionality of columns present in \"Add Police Personnels\" window.")
	public void PV_CrimeMapping_46(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_firstname)).click();
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_firstname)).getAttribute("aria-sort");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_firstname)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Sorting\" icon of the \"First Name\" column.");
		String s2=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_firstname)).getAttribute("aria-sort");
		Assert.assertNotEquals(s1, s2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get records in alphabetical sorting order of \"First Name\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_lastname)).click();
		Thread.sleep(2000);
		String s3=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_lastname)).getAttribute("aria-sort");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_lastname)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Sorting\" icon of the \"Last Name\" column.");
		String s4=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_lastname)).getAttribute("aria-sort");
		Assert.assertNotEquals(s3, s4);
		
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should get records in alphabetical sorting order of \"Last Name\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_02");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_badgeno)).click();
		Thread.sleep(2000);
		String s5=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_badgeno)).getAttribute("aria-sort");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_badgeno)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on \"Sorting\" icon of the \"Badge Number\" column.");
		String s6=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_badgeno)).getAttribute("aria-sort");
		Assert.assertNotEquals(s5, s6);
		
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_3</b> : User should get records in sorting order of \"Badge Number\" data fields."));
		ll.Screenshotnew(driver,i,method.getName()+"_03");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_designation)).click();
		Thread.sleep(2000);
		String s7=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_designation)).getAttribute("aria-label");
		driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_designation)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Sorting\" icon of the \"Designation\" column.");
		String s8=driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_designation)).getAttribute("aria-label");
		Assert.assertNotEquals(s7, s8);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_4</b> : User should get records in sorting order of \"Designation\" data fields."));
	}
	
	@Test(priority=44,description="To verify that user gets validation message when perform \"Cancel\"/\"X\"(close) functionality after Adding details in \"Add Police Personnels\" window.")
	public void PV_CrimeMapping_47() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.seach_txtbox_1st)).sendKeys("Megha");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_firstname_pptable)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\" button of \"Add Police Personnels\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes'\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"Add Police Personnels\" window should also close."));
		
	}
	
	@Test(priority=45,description="To verify that user is able to \"Cancel\" validation message for unsaved changes of \"Add Police Personnels\" window.")
	public void PV_CrimeMapping_48() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Police Personnel\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.seach_txtbox_1st)).sendKeys("Megha");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_firstname_pptable)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\" button of \"Add Police Personnels\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes'\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"Add Police Personnels\" window shouldn't close."));
	}
	
	@Test(priority=46,description="To verify that user is able to get \"Add Attachment\" window by performing \"Add Attachment\" functionality from dropdown list.")
	public void PV_CrimeMapping_49() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Attachment\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_atttype_attwin)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_attwin)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get \"Add Attachment\" window with following :</br>"
				+ "1. Buttons: \"Cancel\", \"Save\", \"X\"(close).</br>"
				+ "2. Dropdown: \"Attachment Type\" , \"Attachment\".</br>"
				+ "3. Text-box : \"Description\"."));
	}
	
	@Test(priority=47,description="To verify that user is able to add attachment in any particular saved crime by performing \"Add Attachment\" functionality from dropdown list.")
	public void PV_CrimeMapping_50() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Attachment\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_atttype_attwin)).sendKeys("Identity");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select attachment type from \"Attachment Type\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_attwin)).sendKeys("C:\\Users\\neha.p\\Pictures\\user_image.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select file from file browse window and click on \"Open\" button of window.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).sendKeys("This is identity attachment.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Save\" button of \"Add Attachment\" window.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_att_attsec)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"Add Attachment\" window.</br>"
				+ "2. Added attachment for selected crime should display in list of \"Attachment\" section of that crime."));
	}
	
	@Test(priority=48,description="To verify that user is able to close \"Add Attachment\" window.")
	public void PV_CrimeMapping_51() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Attachment\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"X\"(close) button of \"Add Attachment\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to close \"Add Attachment\" window."));
	}
	
	@Test(priority=49,description="To verify that user is able to perform \"Cancel\" functionality of \"Add Attachment\" window.")
	public void PV_CrimeMapping_52() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Attachment\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\" button of \"Add Attachment\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of \"Add Attachment\" window and \"Add Attachment\" window should close."));
	}

	@Test(priority=50,description="To verify that user gets validation message when perform \"Save\" functionality with blank required details of \"Add Attachment\" window.")
	public void PV_CrimeMapping_53() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Attachment\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Save\" button without filling mandatory details of \"Add Attachment\" window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_file_attwin)).getText(), "The Attachment field is required.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get validation message like \"The Attachment field is required.\" below respective field."));
	}
	
	@Test(priority=51,description="To verify that user gets validation message when perform \"Cancel\"/ functionality after Adding details in \"Add Attachment\" window.")
	public void PV_CrimeMapping_54() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Attachment\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_atttype_attwin)).sendKeys("Identity");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select attachment type from \"Attachment Type\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_attwin)).sendKeys("C:\\Users\\neha.p\\Pictures\\user_image.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select file from file browse window and click on \"Open\" button of window.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).sendKeys("This is identity attachment.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Cancel\" button of \"Add Attachment\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes'\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"Add Attachment\" window should also close."));
	}
	
	@Test(priority=52,description="To verify that user is able to \"Cancel\" validation message for unsaved changes of \"Add Attachment\" window.")
	public void PV_CrimeMapping_55() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Attachment\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_atttype_attwin)).sendKeys("Identity");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select attachment type from \"Attachment Type\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_attwin)).sendKeys("C:\\Users\\neha.p\\Pictures\\user_image.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select file from file browse window and click on \"Open\" button of window.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).sendKeys("This is identity attachment.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Cancel\" button of \"Add Attachment\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(UserManagement_repository.title_window)).size()!=0, true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes'\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"Add Attachment\" window shouldn't close."));
	}
	
	@Test(priority=53,description="To verify that user is able to edit any particular saved crime by performing \"Edit Crime\" functionality from dropdown list.")
	public void PV_CrimeMapping_56() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.verify_recno_first)).getText();
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editcrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Edit Crime\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Edit Crime (Record No." +s1+")");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Murder");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Edit selection of type of crime from \"Select Crime\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("Moderate");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit selection of Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_home_map)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).sendKeys("Enter Coordinates");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit selection of location from \"Select Location\" dropdown.");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long)).sendKeys("72.549830");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat)).sendKeys("23.027090");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit Longitude and Latitude values from respective text-boxes.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-29-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Edit selection of Crime Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Edit selection of Crime End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).sendKeys("Edit Test2.");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Edit Crime Incident Summary in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).sendKeys("Test Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Edit Crime description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_registercrime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-17</b> : Click on \"Update\" button of \"Edit Crime\" page.");
		Thread.sleep(5000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crime Mappings");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\"/ button of \"Edit Crime\" page and redirect back to \"Crime Mappings\" page.</br>"
				+ "2. Edited details should update on portal."));
		
	}
	
	
	
	
	
	@Test(priority=54,description="To verify that user is able to perform \"Cancel\" functionality of \"Edit Crime\" page.")
	public void PV_CrimeMapping_57() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.verify_recno_first)).getText();
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editcrime)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Edit Crime\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Edit Crime (Record No." +s1+")");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\" button of \"Edit Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crime Mappings");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of \"Edit Crime\" page and redirect back to \"Crime Mappings\" page."));
	}
	
	@Test(priority=55,description="To verify that user is able to get back to \"Home\" page from \"Edit Crime\" page by clicking on \"Home\" icon.")
	public void PV_CrimeMapping_58() throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test2.");
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.verify_recno_first)).getText();
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "This is Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editcrime)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Edit Crime\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Edit Crime (Record No." +s1+")");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_Home)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Home\" icon in \"Edit Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Home");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get back to \"Home\" page from \"Edit Crime\" page."));
	}
	
	@Test(priority=56,description="To verify that user is able to get \"New Event\" page by performing \"Add Event\" functionality from dropdown list.")
	public void PV_CrimeMapping_59() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_ipc_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_selelocation_addeventsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat_addeventsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long_addeventsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.repoTime_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_addeventsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_save1)).isDisplayed(), true);
		
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get \"New Event\" page with following two sections : Window section , Map.</br>"
				+ "1. Window section contains following : \r\n"
				+ "1.1. Dropdowns: \"Select Event\",\"Severity\", \"Select Location\".\r\n"
				+ "1.2. Text-boxes : \"IPC\" , \"Latitude\" , \"Longitude\" , \"Event Time\" , \"Event End Time\" , \"Reporting Time\",\",\"Summary\" , \"Description\".\r\n"
				+ "1.3. Buttons : \"Cancel\" ,\"Save\".\r\n"
				+ "2. Map contains following :\r\n"
				+ "Icon Buttons : Kebab Menu (3 vertical dot) , \"Tools\",\"+\"(Zoom in) , \"-\"(Zoom out) , \"Home\" (Reset perspective) , \"Compass\"."));
	}
	
	@Test(priority=57,description="To verify that user is able to add event under any particular saved crime by performing \"Add Event\" functionality from dropdown list.")
	public void PV_CrimeMapping_60() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Attempt to Murder (E)");
		Thread.sleep(7000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select event from \"Select Event\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("High");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_ipc_crime)).sendKeys("section 307");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter \"IPC\" of crime into respective text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selelocation_addeventsec)).sendKeys("Enter Coordinates");
		Thread.sleep(7000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Select \"Enter Coordinates\" option from \"Select Location\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long_addeventsec)).sendKeys("72.551505");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Enter Longitude value in \"Longitude\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat_addeventsec)).sendKeys("23.022887");
		Thread.sleep(1000);
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Enter Latitude value in \"Latitude\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-29-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Select Event Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-29-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-17</b> : Select Event End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventsec)).sendKeys("This is Event.");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-18</b> : Enter Crime event Summary in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_addeventsec)).sendKeys("Test event Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-19</b> : Enter Crime event description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save1)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-20</b> : Click on \"Save\" button from \"New Event\" page.");
		
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e2).perform();
		Thread.sleep(3000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.header_crimeinfo)).getText(), "Event Information");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"New Event\" page navigate to \"Crime Mappings\" page.</br>"
				+ "2. Added event should display under crime in which event is added in \"Crime Mappings\" page.</br>"
				+ "3. Added event of crime should display on map."));
	}
	
	@Test(priority=58,description="To verify that user is able to perform \"Cancel\" functionality of  \"New Event\" page.")
	public void PV_CrimeMapping_61() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(4000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\"  button of \"New Event\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crime Mappings");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of \"New Event\" page and back to \"Crime Mappings\" page."));
	}
	
	@Test(priority=59,description="To verify that user is able to get back to \"Home\" page from \"New Event\" page by clicking on \"Home\" icon.")
	public void PV_CrimeMapping_62() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_Home)).click();
		Thread.sleep(4000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Home\" icon from \"New Event\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Home");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get back to \"Home\" page from \"New Event\" page."));
	}
	
	@Test(priority=60,description="To verify that user gets validation messages when perform \"Save\" functionality of \"New Event\" page with selection of \"Current Location\" option and blank mandatory details.")
	public void PV_CrimeMapping_63() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(10000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save1)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Save\" button without filling mandatory fields.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_summary_addeventsec)).getText(), "The Summary field is required.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_ipc_addeventsec)).getText(), "The IPC field is required.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get validation messages like :</br>"
				+ "\"The IPC field is required.\" </br>"
				+ "\"The Summary field is required.\" below respective fields."));
	}
	
	@Test(priority=61,description="To verify that user gets validation messages when perform \"Save\" functionality of \"New Event\" page with selection of \"Enter Coordinates\" option and blank mandatory details.")
	public void PV_CrimeMapping_64() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selelocation_addeventsec)).sendKeys("Enter Coordinates");
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select \"Enter Coordinates\" option from \"Select Location\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save1)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Save\" button without filling mandatory fields.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_summary_addeventsec)).getText(), "The Summary field is required.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_ipc_addeventsec)).getText(), "The IPC field is required.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_long_addeventsec)).getText(), "The Longitude field is required.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_lat_addeventsec)).getText(), "The Latitude field is required.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get validation messages like :</br>"
				+ "\"The IPC field is required.\" ,</br>"
				+ "\"The Longitude field is required.\" ,</br>"
				+ "\"The Latitude field is required.\",</br>"
				+ "\"The Summary field is required.\" below respective fields."));
		
	}
	
	@Test(priority=62,description="To verify that user gets validation message when select invalid date or time for \"Event Time\" from Date & Time Picker of \"New Event\" form.")
	public void PV_CrimeMapping_65(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		Date dt = new Date(); 
		 
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(dt); 
		calendar.add(Calendar.DATE, 1); 
		dt = calendar.getTime(); 
		 
		String tommorowsDate = new SimpleDateFormat("MM/dd/yyyy").format(dt); 
		 
		//enter tomorrow's date in the field 
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		Thread.sleep(1000);
		WebElement tomDate = driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)); 
		tomDate.sendKeys(tommorowsDate); 
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_ipc_crime)).click();
		Thread.sleep(1000);
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select invalid \"Event Time\" and fill all required details in \"New Event\" form.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "Start Date-Time Must Not Be Of Future");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : </br>1. User should able to select invalid \"Event Time\" from date & time picker.</br>"
				+ "2. User should get validation message like \"Start Date-Time Must Not Be Of Future\" below respective field."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should able to click on \"OK\" button of validation message popup and validation message popup should close."));
	}
	
	@Test(priority=63,description="To verify that user gets validation message when select invalid date or time for \"Event End Time\" from Date & Time Picker of \"New Event\" form.")
	public void PV_CrimeMapping_66(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		Date dt = new Date(); 
		 
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(dt); 
		calendar.add(Calendar.DATE, 1); 
		dt = calendar.getTime(); 
		 
		String tommorowsDate = new SimpleDateFormat("MM/dd/yyyy").format(dt); 
		 
		//enter tomorrow's date in the field 
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		Thread.sleep(1000);
		WebElement tomDate = driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)); 
		tomDate.sendKeys(tommorowsDate);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_ipc_crime)).click();
		Thread.sleep(1000);
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select invalid \"Event End Time\" and fill all required details in \"New Event\" form.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "End Date-Time Must Not Be Of Future");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : </br>1. User should able to select invalid \"Event End Time\" from date & time picker.</br>"
				+ "2. User should get validation message like \"End Date-Time Must Not Be Of Future\" below respective field."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should able to click on \"OK\" button of validation message popup and validation message popup should close."));
	
	}
	
	@Test(priority=64,description="To verify that user gets validation message when select  \"Event End Time\" is earlier than Event start time from Date & Time Picker of \"New Event\" form.")
	public void PV_CrimeMapping_67(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.contextClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Right-click on particular crime from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addevent)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Add Event\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "New Event");
		Date dt = new Date(); 
		 
		Calendar calendar = Calendar.getInstance(); 
		calendar.setTime(dt); 
		calendar.roll(Calendar.DATE, -1); 
		dt = calendar.getTime(); 
		 
		String tommorowsDate = new SimpleDateFormat("MM/dd/yyyy").format(dt); 
		 
		//enter tomorrow's date in the field 
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		Thread.sleep(1000);
		WebElement tomDate = driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)); 
		tomDate.sendKeys(tommorowsDate);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_ipc_crime)).click();
		Thread.sleep(1000);
		
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Select Event End Date is earlier than Event Start Date.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).getText(), "End Date-Time Must Not Be Earlier Than Start Date-Time");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get validation message like \"End Date-Time Must Not Be Earlier Than Start Date-Time\"."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_OK)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"OK\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should able to click on \"OK\" button of validation message popup and validation message popup should close."));
	
	}
	
	@Test(priority=65,description="To verify that user is able to perform \"Add Event Detail\" functionality for particular crime event.")
	public void PV_CrimeMapping_68(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-Click on particular event of \"Crime\".");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_addperson)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_addpp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_addattachment)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_editevent)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_addeventdetail)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_discard)).isDisplayed(), true);
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addeventdetail)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Add Event Detail\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Event Detail");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).sendKeys("Test Event detail summary.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Enter \"Summary\" of new event in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).sendKeys("Test Event details.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter \"Details\" of new event in \"Details\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Save\" button of \"New Event Detail\" window.");
		WebElement e3= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.doubleClick(e3).perform();
		Thread.sleep(3000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_added_eventdetail)).getText(), "Test Event detail summary.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_added_eventdetail)).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.header_crimeinfo)).getText(), "Event Detail Information");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"New Event Detail\" window and window should close.</br>"
				+ "2. Added event details should display under that particular event."));
	}
	
	@Test(priority=66,description="To verify that user is able to get details of Crime or Crime Event by clicking on crime from \"Crime Tree\" section in \"Crime Mappings\" page.")
	public void PV_CrimeMapping_24() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.doubleClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on expand icon of \"Event\" from \"Crime Tree\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_added_eventdetail)).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.header_crimeinfo)).getText(), "Event Detail Information");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.recordno_crimeinfo)).getText(), "Summary");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on particular crime/crime event from \"Crime Tree\" section in \"Crime Mapping\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.header_crimeinfo)).getText(), "Event Information");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.recordno_crimeinfo)).getText(), "Event Time");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get \"Event Information\" of saved crime event with following details : </br>"
				+ "\"Event Time\" , \"Event End Time\" , \"Reporting Time\" ,\"Severity\" ,\"Summary\" , \"Description\" ,\"Investigation Status\",\"Description\" ,\"Sequence\",\"Creator Name\",\"Creation Time\"."));
	}
	
	
	@Test(priority=67,description="To verify that user is able to perform \"Search\" functionality from \"Crime Mappings\" page.")
	public void PV_CrimeMapping_25() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).size()!=0, false);
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.searchbox_crimemapping)).sendKeys("This is Event");
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).isDisplayed(), true);
	}
	
	
	@Test(priority=68,description="To verify that user is able to close \"New Event Detail\" window.")
	public void PV_CrimeMapping_69() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-Click on particular event of \"Crime\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addeventdetail)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Add Event Detail\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on close(\"X\") button of \"New Event Detail\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to close \"New Event Detail\" window."));
	}
	
	@Test(priority=69,description="To verify that user is able to perform \"Cancel\" functionality of  \"New Event Detail\" window.")
	public void PV_CrimeMapping_70() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-Click on particular event of \"Crime\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addeventdetail)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Add Event Detail\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Cancel\" button of \"New Event Detail\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of \"New Event Detail\" window and \"New Event Detail\" window should close."));
	}
	
	@Test(priority=70,description="To verify that user gets validation message while perform \"Save\" functionality of \"New Event Detail\" with blank required details.")
	public void PV_CrimeMapping_71() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-Click on particular event of \"Crime\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addeventdetail)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Add Event Detail\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Save\" button without entering mandatory details of \"New Event Detail\" window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_summary_addeventdetail)).getText(), "The Summary field is required.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.val_details_addeventdetail)).getText(), "The Details field is required.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should gets validation message like </br>"
				+ "\"The Summary field is required.\",</br>"
				+ "\" The Details field is required.\" below their respective fields."));
	}
	
	@Test(priority=71,description="To verify that user gets validation message when perform \"Cancel\" functionality after adding details into \"New Event Detail\" window.")
	public void PV_CrimeMapping_72() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-Click on particular event of \"Crime\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addeventdetail)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Add Event Detail\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Event Detail");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).sendKeys("Test Event detail summary.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Enter \"Summary\" of new event in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).sendKeys("Test Event details.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter \"Details\" of new event in \"Details\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Cancel\" button of \"New Event Detail\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes'\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"New Event Detail\" window should also close."));
	}
	
	@Test(priority=71,description="To verify that user is able to \"Cancel\" validation message for unsaved changes of \"New Event Detail\" window.")
	public void PV_CrimeMapping_73() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-Click on particular event of \"Crime\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_addeventdetail)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Add Event Detail\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "New Event Detail");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).sendKeys("Test Event detail summary.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Enter \"Summary\" of new event in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).sendKeys("Test Event details.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Enter \"Details\" of new event in \"Details\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Cancel\" button of \"New Event Detail\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Cancel\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"New Event Detail\" window shouldn't close."));
	}
	
	@Test(priority=73,description="To verify that user is able to perform \"Edit Event Detail\" functionality for particular event.")
	public void PV_CrimeMapping_74() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.doubleClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on expand icon of \"Event\" from \"Crime Tree\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_added_eventdetail)).click();
		Thread.sleep(2000);
		WebElement e3= driver.findElement(By.xpath(CrimeMapping_repository.verify_added_eventdetail));
		act.contextClick(e3).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Right-Click on particular event detail of \"Crime Event\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editeventdetails)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Edit Event Detail\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Event Detail");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).sendKeys("Edit Event detail summary.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit \"Summary\" of new event from \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).sendKeys("Test edit Event details.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit \"Details\" of new event from \"Details\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Save\" button of \"Edit Event Detail\" window.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail)).getText(), "Edit Event detail summary.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Edit Event Detail\" window and window should close.</br>"
				+ "2. Edited details of event should update on portal accordingly."));
	}
	
	@Test(priority=74,description="To verify that user is able to close \"Edit Event Detail\" window.")
	public void PV_CrimeMapping_75() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.doubleClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on expand icon of \"Event\" from \"Crime Tree\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail)).click();
		Thread.sleep(2000);
		WebElement e3= driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail));
		act.contextClick(e3).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Right-Click on particular event detail of \"Crime Event\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editeventdetails)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Edit Event Detail\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Event Detail");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on close(\"X\") button of \"Edit Event Detail\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to close \"Edit Event Detail\" window."));
	}
	
	@Test(priority=75,description="To verify that user is able to perform \"Cancel\" functionality of \"Edit Event Detail\" window.")
	public void PV_CrimeMapping_76() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.doubleClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on expand icon of \"Event\" from \"Crime Tree\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail)).click();
		Thread.sleep(2000);
		WebElement e3= driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail));
		act.contextClick(e3).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Right-Click on particular event detail of \"Crime Event\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editeventdetails)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Edit Event Detail\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Event Detail");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Click on \"Cancel\" button of \"Edit Event Detail\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of \"Edit Event Detail\" window and \"Edit Event Detail\" window should close."));
	}
	
	@Test(priority=76,description="To verify that user gets validation message when perform \"Cancel\" functionality after editing details into \"Edit Event Detail\" window.")
	public void PV_CrimeMapping_77() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.doubleClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on expand icon of \"Event\" from \"Crime Tree\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail)).click();
		Thread.sleep(2000);
		WebElement e3= driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail));
		act.contextClick(e3).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Right-Click on particular event detail of \"Crime Event\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editeventdetails)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Edit Event Detail\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Event Detail");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).sendKeys("Test Event detail summary.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit \"Summary\" of new event from \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).sendKeys("Test edit Event details.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit \"Details\" of new event from \"Details\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Cancel\" button of \"Edit Event Detail\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"Edit Event Detail\" window should also close."));
	}
	
	@Test(priority=77,description="To verify that user is able to \"Cancel\" validation message for unsaved changes of \"Edit Event Detail\" window.")
	public void PV_CrimeMapping_78() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.doubleClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on expand icon of \"Event\" from \"Crime Tree\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail)).click();
		Thread.sleep(2000);
		WebElement e3= driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail));
		act.contextClick(e3).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Right-Click on particular event detail of \"Crime Event\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editeventdetails)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Edit Event Detail\" option from dropdown list.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Event Detail");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_addeventdetail)).sendKeys("Test Event detail summary.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit \"Summary\" of new event from \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_details_addevebtdetail)).sendKeys("Test edit Event details.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit \"Details\" of new event from \"Details\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Cancel\" button of \"Edit Event Detail\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Cancel\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"Edit Event Detail\" window shouldn't close."));
	}
	
	@Test(priority=78,description="To verify that user is able to discard functionality added Event Detail from \"Crime Mapping\" page.")
	public void PV_CrimeMapping_79() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.doubleClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on expand icon of \"Event\" from \"Crime Tree\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail)).click();
		Thread.sleep(2000);
		WebElement e3= driver.findElement(By.xpath(CrimeMapping_repository.verify_edited_eventdetail));
		act.contextClick(e3).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Right-Click on particular event detail of \"Crime Event\".");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_discard)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Discard\" option from dropdown list.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("Are you sure you want to discard this record?", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.toast_msg)).getText(), "Successfully discarded!");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.verify_edited_eventdetail)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes\" button of validation  message popup and validatin message popup should close.</br>"
				+ "2. User should get toast validation message like \"Successfully discarded!\" .</br>"
				+ "3. Discarded event detail should remove from portal."));
	}
	
	@Test(priority=79,description="To verify that user is able to perform \"Edit Event\" functionality of particular Crime Event.")
	public void PV_CrimeMapping_80() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-click on particular crime event from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editevent)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Edit Event\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Attempt to Murder (E)");
		Thread.sleep(7000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit selection of event from \"Select Event\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("Moderate");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit selection of Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_ipc_editevent)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_ipc_editevent)).sendKeys("section 306");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Edit \"IPC\" of crime into respective text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selelocation_addeventsec)).sendKeys("Enter Coordinates");
		Thread.sleep(7000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Edit selection of any of option from \"Select Location\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long_addeventsec)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long_addeventsec)).sendKeys("72.551510");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Edit Longitude value from \"Longitude\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat_addeventsec)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat_addeventsec)).sendKeys("23.022889");
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Edit Latitude value from \"Latitude\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-30-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-17</b> : Edit selection of Event Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-30-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-18</b> : Edit selection of Event End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_editevent)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary_editevent)).sendKeys("Edit Crime Event.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-19</b> : Edit Crime event Summary from \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_addeventsec)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_addeventsec)).sendKeys("Test event Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-20</b> : Edit Crime event description from \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save1)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-21</b> : Click on \"Save\" button from \"Edit Event\" page.");
		WebElement e3= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e3).perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "Edit Crime Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.header_crimeinfo)).getText(), "Event Information");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"Edit Event\" page and navigate to \"Crime Mappings\" page.</br>"
				+ "2. Edited event details  should update on portal."));
	}
	
	@Test(priority=80,description="To verify that user is able to perform \"Cancel\" functionality of \"Edit Event\" page.")
	public void PV_CrimeMapping_81() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-click on particular crime event from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_editevent)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Edit Event\" option from dropdown list.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(4000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Cancel\" button of \"Edit Event\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crime Mappings");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should redirect back to \"Crime Mappings\" page from \"Edit Event\" page."));
		
	}
	
	@Test(priority=81,description="To verify that user is able to \"Cancel\" validation message of discard crime event record.")
	public void PV_CrimeMapping_83() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-click on particular crime event from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_discard)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Discard\" option from dropdown list.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("Are you sure you want to discard this record?", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).size()!=0, true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of validation message popup and validation message popup should close."));
	}
	
	@Test(priority=82,description="To verify that user is able to perform \"Discard\" functionality of particular Crime Event.")
	public void PV_CrimeMapping_82() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test2.");
		Actions act = new Actions(driver);
		WebElement e1= driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree));
		act.doubleClick(e1).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on expand icon of \"Crime\" from \"Crime Tree\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).getText(), "This is Event.");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).click();
		Thread.sleep(1000);
		WebElement e2= driver.findElement(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree));
		act.contextClick(e2).perform();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Right-click on particular crime event from \"Crime Tree\" section in \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_discard)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Discard\" option from dropdown list.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("Are you sure you want to discard this record?", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.toast_msg)).getText(), "Successfully discarded!");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.verify_crimeevent_ceimetree)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes\" button of validation message popup and validation message popup should close.</br>"
				+ "2. User should get toast validation message like \"Successfully discarded!\".</br>"
				+ "3. Selected particular crime event should discarded from portal."));
	}
	
	@Test(priority=83,description="To verify that user is able to get \"Attachment\" section of particular selected crime in \"Crime Mappings\" page.")
	public void PV_CrimeMapping_84() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_addattachment)).isDisplayed(), true);
		
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_next)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_previous)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_entries)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.searchbox_attachmentsec)).isDisplayed(), true);
		
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_attatype_attsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_view_attsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_desc_attsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_type_attsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_creatorname)).isDisplayed(), true);
		WebElement e1=driver.findElement(By.xpath(CrimeMapping_repository.scroll_to_hori));
		Coordinates co1=((Locatable)e1).getCoordinates();
		co1.onPage();
		co1.inViewPort();
		Thread.sleep(5000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_lastmodiname_attsec)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_lastmodificationtime)).isDisplayed(), true);
		
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.col_lbl_creationtime)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get \"Attachment\" section of selected crime with following :</br>"
				+ "1. List of attachment of selected crime(if added).</br>"
				+ "2. Buttons : \"+Add Attachment\" , \"Next\" , \"Previous\",Page control No. , \"Actions\" dropdown.</br>"
				+ "3. Text-box : \"SEARCH\".</br>"
				+ "4. Data table of added attachments with column fields like :</br> \"Actions\" , \"AttachmentType\" , \"View\" , \"Description\",\"Type\" , \"Creator Name\" ,Creation Time\" , \"Last Modifier Name\" , \"Last Modification Name."));
	}
	
	@Test(priority=84,description="To verify that user is able to add attachment for particular crime by performing \"Add Attachment\" functionality from \"Attachment\" section in \"Crime Mappings\" page.")
	public void PV_CrimeMapping_85() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_addattachment)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"+Add Attachment\" button from \"Attachment\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Add Attachment");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_atttype_attwin)).sendKeys("Crime Attachment");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Select attachment type from \"Attachment Type\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_attwin)).sendKeys("C:\\Users\\neha.p\\Pictures\\download.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Select file from file browse window and click on \"Open\" button of window.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).sendKeys("Test1");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Enter description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(4000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Save\" button of \"Add Attachment\" window.");
		String s2=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		Thread.sleep(1000);	
		Assert.assertNotEquals(s1,s2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"Add Attachment\" window.</br>"
				+ "2. Added attachment for selected crime should display in list of \"Attachment\" section of that crime."));
	}
	
	@Test(priority=85,description="To verify that user is able to view added attachment by clicking on visibility icon from \"Attachment\" section of selected crime in \"Crime Mapping\" page.")
	public void PV_CrimeMapping_86(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_viewatta_attsec)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click to view attachment icon of particular attachment from \"Attachment\" section.");
		String parent=driver.getWindowHandle();
		Set<String> s=driver.getWindowHandles();

		// Now iterate using Iterator
		Iterator<String> I1= s.iterator();

		while(I1.hasNext())
		{

		String child_window=I1.next();


		if(!parent.equals(child_window))
		{
		driver.switchTo().window(child_window);
		Thread.sleep(2000);
		String Title_child = driver.switchTo().window(child_window).getTitle();
		System.out.println(Title_child);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get existing attachment in new tab of browser."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.close();
		
		driver.switchTo().window(parent);
		String Title_parent=driver.switchTo().window(parent).getTitle();
		System.out.println(Title_parent);
		Assert.assertNotEquals(Title_child, Title_parent);
		}
		}
		
	}
	
	@Test(priority=86,description="To verify that user is able to get \"Attachment Detail\" window by performing \"View Detail\" functionality from \"Actions\" dropdown of particular attachment in \"Attachment\" section of \"Crime Mappings\" page.")
	public void PV_CrimeMapping_87() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_viewdetail)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"View Detail \" button of particular attachment from \"Attachment\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Attachment Detail");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.lnk_view_attdetails_win)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get \"Attachment Detail\" window with following :</br>"
				+ "1. Buttons: \"X\"(close).</br>"
				+ "2. Pre filled details of crime record like : \"Attachment Type\" , \"Description\", \"Creator Name(Badge No)\" , \"creation Time\" , \"Last Modifier Name (BadgeNo)\", \"Last Modification Time\".</br>"
				+ "3. Link : \"View\" attachment."));
		Thread.sleep(1000);
	}
	
	@Test(priority=87,description="To verify that user is able to close \"Attachment Detail\" window.")
	public void PV_CrimeMapping_88() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_viewdetail)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"View Detail \" button of particular attachment from \"Attachment\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on close(\"X\") button of \"Attachment Detail\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to close \"Attachment Detail\" window."));
	}
	
	@Test(priority=88,description="To verify that user is able to view attachment of selected crime record by clicking on \"View\" link from \"Attachment Detail\" window.")
	public void PV_CrimeMapping_89(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_viewdetail)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"View Detail \" button of particular attachment from \"Attachment\" section.");
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_view_attdetails_win)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"View\" link from \"Attachment Detail\" window.");
		String parent=driver.getWindowHandle();
		Set<String> s=driver.getWindowHandles();

		// Now iterate using Iterator
		Iterator<String> I1= s.iterator();

		while(I1.hasNext())
		{

		String child_window=I1.next();


		if(!parent.equals(child_window))
		{
		driver.switchTo().window(child_window);
		Thread.sleep(2000);
		String Title_child = driver.switchTo().window(child_window).getTitle();
		System.out.println(Title_child);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get attachment of crime record in new tab of browser."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.close();
		
		driver.switchTo().window(parent);
		String Title_parent=driver.switchTo().window(parent).getTitle();
		System.out.println(Title_parent);
		Assert.assertNotEquals(Title_child, Title_parent);
		}
		}
	}
	
	@Test(priority=89,description="To verify that user is able to edit attachment by performing \"Edit\" functionality from \"Actions\" dropdown of particular attachment in \"Attachment\" section of \"Crime Mappings\" page.")
	public void PV_CrimeMapping_90() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"Edit\" button of particular attachment which want to edit from \"Attachment\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Attachment");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_atttype_attwin)).sendKeys("Identity");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit attachment type from \"Attachment Type\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_attwin)).sendKeys("C:\\Users\\neha.p\\Pictures\\user_image.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit attachment file by uploading new attachment file from \"Attachment\" field.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).sendKeys("Test Edit attachment functionality.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Edit description from \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save)).click();
		Thread.sleep(4000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Save\" button of \"Edit Attachment\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_desc_attsec)).getText(), "Test Edit attachment functionality.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Save\" button of \"Edit Attachment\" window and window should close.</br>"
				+ "2. Edited details of attachment should update on portal."));
	}
	
	@Test(priority=90,description="To verify that user is able to view existing attachment by clicking on \"View\" link from \"Edit Attachment\" window.")
	public void PV_CrimeMapping_91(Method method) throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"Edit\" button of particular attachment which want to edit from \"Attachment\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Attachment");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_view_attdetails_win)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"View\" link from \"Edit Attachment\" window.");
		String parent=driver.getWindowHandle();
		Set<String> s=driver.getWindowHandles();

		// Now iterate using Iterator
		Iterator<String> I1= s.iterator();

		while(I1.hasNext())
		{

		String child_window=I1.next();


		if(!parent.equals(child_window))
		{
		driver.switchTo().window(child_window);
		Thread.sleep(2000);
		String Title_child = driver.switchTo().window(child_window).getTitle();
		System.out.println(Title_child);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should get attachment of crime record in new tab of browser."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.close();
		
		driver.switchTo().window(parent);
		String Title_parent=driver.switchTo().window(parent).getTitle();
		System.out.println(Title_parent);
		Assert.assertNotEquals(Title_child, Title_parent);
		}
		}
		
	}
	
	@Test(priority=91,description="To verify that user is able to close \"Edit Attachment\" window.")
	public void PV_CrimeMapping_92() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"Edit\" button of particular attachment which want to edit from \"Attachment\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Attachment");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_close)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"X\"(close) button of \"Edit Attachment\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to close \"Edit Attachment\" window."));
	}
	
	@Test(priority=92,description="To verify that user is able to perform \"Cancel\" functionality of \"Edit Attachment\" window.")
	public void PV_CrimeMapping_93() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"Edit\" button of particular attachment which want to edit from \"Attachment\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Attachment");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click on \"Cancel\" button of \"Edit Attachment\" window.");
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of \"Edit Attachment\" window and \"Edit Attachment\" window should close."));
		
	}
	
	@Test(priority=93,description="To verify that user gets validation message when perform \"Cancel\" functionality after editing details in \"Edit Attachment\" window.")
	public void PV_CrimeMapping_94() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"Edit\" button of particular attachment which want to edit from \"Attachment\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Attachment");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_atttype_attwin)).sendKeys("Crime Attachment");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit attachment type from \"Attachment Type\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_attwin)).sendKeys("C:\\Users\\neha.p\\Pictures\\user_image.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit attachment file by uploading new attachment file from \"Attachment\" field.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).sendKeys("Test attachment functionality.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Edit description from \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(4000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Cancel\" button of \"Edit Attachment\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes'\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"Edit Attachment\" window should also close."));
	}
	
	@Test(priority=94,description="To verify that user is able to \"Cancel\" validation message for unsaved changes of \"Edit Attachment\" window.")
	public void PV_CrimeMapping_95() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"Edit\" button of particular attachment which want to edit from \"Attachment\" section.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_window)).getText(), "Edit Attachment");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_atttype_attwin)).sendKeys("Crime Attachment");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Edit attachment type from \"Attachment Type\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_browse_attwin)).sendKeys("C:\\Users\\neha.p\\Pictures\\user_image.jpg");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit attachment file by uploading new attachment file from \"Attachment\" field.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des_attwin)).sendKeys("Test attachment functionality.");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Edit description from \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(4000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Click on \"Cancel\" button of \"Edit Attachment\" window.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("You have unsaved changes.", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		Assert.assertEquals(driver.findElements(By.xpath(CrimeMapping_repository.title_window)).size()!=0, true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes'\" button of validation message popup and validation message popup should close.</br>"
				+ "2. \"Edit Attachment\" window shouldn't close."));
	}
	
	@Test(priority=95,description="To verify that user is able to discard attachment by performing \"Discard\" functionality from \"Actions\" dropdown of particular attachment in \"Attachment\" section of \"Crime Mappings\" page.")
	public void PV_CrimeMapping_96() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_discard_first)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"Discard\" button of particular attachment which want to delete from \"Attachment\" section.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("Are you sure you want to discard this record?", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.toast_msg)).getText(), "Successfully discarded!");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		String s2=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		Assert.assertNotEquals(s1,s2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Yes\" button of validation message popup and message pop up should close.</br>"
				+ "2. User should get validation message like : \"Successfully discarded!\".</br>"
				+ "3. Selected attachment record should delete from \"Attachment\" section."));
	}
	
	@Test(priority=96,description="To verify that user is able to \"Cancel\" validation message of discard attachment record.")
	public void PV_CrimeMapping_97() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_discard_first)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Click on \"Actions\"->\"Discard\" button of particular attachment which want to delete from \"Attachment\" section.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("Are you sure you want to discard this record?", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
        Thread.sleep(1000);	
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(1000);	
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		String s2=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		Assert.assertEquals(s1,s2);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should able to click on \"Cancel\" button of validation message popup and validation message popup should close."));
	}
	
	@Test(priority=97,description="To verify that user is able to perform \"SEARCH\" functionality of \"Attachment\" section of particular selected crime.")
	public void PV_CrimeMapping_98() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(6000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test2.");
		Thread.sleep(2000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_crimedetails_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Crime Details\" option from Actions dropdown of particular crime.");
		driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on particular crime from \"Crime Tree\" section in \"Crime Mappings\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).click();
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText();
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Click on \"Attachment\" tab from \"Crime Mapping\" page.");
		driver.findElement(By.xpath(CrimeMapping_repository.searchbox_attachmentsec)).sendKeys("Test1");
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_desc_attsec)).getText(), "Test1");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_showing_entries)).getText(), "Showing 1 to 1 of 1 entries");
	}
	
	@Test(priority=119,description="To verify that user is able to get \"Edit Crime\" Page.")
	public void PV_CrimeMapping_120() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test1.");
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.verify_recno_first)).getText();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Edit\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Edit Crime (Record No." +s1+")");
		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_lat)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_long)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.repoTime_crime)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_FIRno)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.txtbox_Fileno)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.toggle_swith_crimestatus)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.img_map)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should navigate to \"Edit Crime\" page with following  pre filled crime details :</br>"
				+ "Dropdowns: \"Select Location\", \"Select Crime\",\"Severity\".</br>"
				+ "Text-boxes : \"Latitude\" , \"Longitude\" ,\"Summary\" , \"Description\" , \"Crime Time\", \"Crime End Time\" , \"Reporting Time\".</br>"
				+ "Buttons : \"Cancel\" ,\"Save\" , \"Update & Continue\" .</br>Toggle switch : for \"Investigation Status\" open/close.</br>"
				+ "2. Pre added Crime pinpoint should display on map."));
	}
	
	@Test(priority=120,description="To verify that user is able to edit crime details by performing \"Edit\" functionality from \"Actions\" dropdown of particular crime.")
	public void PV_CrimeMapping_121() throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test3.");
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.verify_recno_first)).getText();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Edit\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Edit Crime (Record No." +s1+")");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Auto Theft");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Edit selection of type of crime from \"Select Crime\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("Moderate");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Edit selection of Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_home_map)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).sendKeys("Click On Map");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Edit selection of location from \"Select Location\" dropdown.");
		WebElement el=driver.findElement(By.xpath(CrimeMapping_repository.img_map));
		int width = el.getSize().getWidth();
		Actions act = new Actions(driver);
		act.moveToElement(el);
		act.moveByOffset((width/4)-5,100).click().build().perform();
		//(width/2)-25
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click at any point of map.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-29-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit selection of Crime Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Edit selection of Crime End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).sendKeys("Edit Test3.");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Edit Crime Incident Summary in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).sendKeys("Test Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Edit Crime description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_registercrime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Click on \"Update\" button of \"Edit Crime\" page.");
		
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crimes");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("Edit Test3.");
		Thread.sleep(2000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime)).getText(), "Edit Test3.");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should able to click on \"Update\" button of \"Edit Crime Page\" and redirect back to \"Crimes\" listing page.</br>"
				+ "2. Edited details of crime should update on portal."));
	}
	
	@Test(priority=121,description="To verify that user is able to perform \"Update & Continue\" functionality of \"Edit Crime\" Page.")
	public void PV_CrimeMapping_122() throws InterruptedException
	{
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test1.");
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.verify_recno_first)).getText();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Edit\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Edit Crime (Record No." +s1+")");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selCrime)).sendKeys("Attempt to Murder");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Edit selection of type of crime from \"Select Crime\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.dd_severity)).sendKeys("Moderate");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-9</b> : Edit selection of Severity value from \"Severity\" dropdown.");
		driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_home_map)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.dd_selLocation)).sendKeys("Click On Map");
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-10</b> : Edit selection of location type from \"Select Location\" dropdown.");
		WebElement el=driver.findElement(By.xpath(CrimeMapping_repository.img_map));
		int width = el.getSize().getWidth();
		Actions act = new Actions(driver);
		act.moveToElement(el);
		act.moveByOffset((width/4)-5,100).click().build().perform();
		//(width/2)-25
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-11</b> : Click at any point of map.");
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.startdate_crime)).sendKeys("03-29-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-12</b> : Edit selection of Crime Time from Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.enddate_crime)).sendKeys("03-28-22");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-13</b> : Edit selection of Crime End Date and Time from opened Date and Time picker.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).clear();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_summary)).sendKeys("Edit Test1.");
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-14</b> : Edit Crime Incident Summary in \"Summary\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).clear();
		driver.findElement(By.xpath(CrimeMapping_repository.txtbox_des)).sendKeys("Test Description.");
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-15</b> : Edit Crime description in \"Description\" text-box.");
		driver.findElement(By.xpath(CrimeMapping_repository.btn_save_continue_registercrime)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-16</b> : Click on \"Update & Continue\" button of \"Edit Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crime Mappings");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.verify_crime_crimetree)).getText(), "Edit Test1");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.header_crimeinfo)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.recordno_crimeinfo)).getText(), "Record No");
		
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_map_crimemapp)).getAttribute("aria-selected"), "true");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_attach_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_person_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.tab_pp_crimemapp)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.img_map)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.btn_tools)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_home_map)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_zoomin)).isDisplayed(), true);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.icon_btn_zoomout)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : </br>1. User should navigate to \"Crime Mappings\" page.</br>"
				+ "2. Edited details of crime should update on portal."));
	}
	
	@Test(priority=122,description="To verify that user is able to perform \"Cancel\" functionality of \"Edit Crime\" page.")
	public void PV_CrimeMapping_123() throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test3.");
		Thread.sleep(2000);
		String s1=driver.findElement(By.xpath(CrimeMapping_repository.verify_recno_first)).getText();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_edit_first)).click();
		Thread.sleep(5000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Edit\" option from Actions dropdown of particular crime.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Edit Crime (Record No." +s1+")");
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_cancel)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Cancel\" button of \"Edit Crime\" page.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.title_header)).getText(), "Crimes");
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result</b> : User should redirect back to \"Crimes\" listing page from \"Edit Crime\" page."));
	}
	
	
	
	@Test(priority=123)
	public void PV_CrimeMapping_125(Method method) throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test3.");
		Thread.sleep(2000);
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_discard_first)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Discard\" option from Actions dropdown of particular crime.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("Are you sure you want to discard this record?", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get validation message like : \r\n"
				+ "\"Are you sure?\r\n"
				+ "Are you sure you want to discard this record?\"."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_cancel)).click();
		Thread.sleep(3000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Cancel\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : User should able to click on \"Cancel\" button of validation message popup and message popup should close."));
	}
	
	@Test(priority=124)
	public void PV_CrimeMapping_124(Method method) throws InterruptedException
	{
		
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-1</b> : Open Browser.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-2</b> : Enter the URL of Police Vertical web portal in address-bar of browser and press Enter key.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-3</b> : Click on  \"Login\" link or button from \"Home\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-4</b> : Enter valid credential of \"Admin\" role in \"Login\" page.");
		ExtentTestManager.getTest().log(Status.INFO,"<b>Step-5</b> : Click on \"Login\" button.");
		
		driver.findElement(By.xpath(CrimeMapping_repository.menu_crimemapping)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.menu_item_crimes)).click();
		Thread.sleep(1000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-6</b> : Click on \"Crime Mappings\"->\"Crimes\" menu from left panel.");
		driver.findElement(By.xpath(CrimeMapping_repository.textbox_search)).sendKeys("This is Test3.");
		Thread.sleep(2000);
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.btn_actions_first)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(CrimeMapping_repository.lnk_discard_first)).click();
		Thread.sleep(2000);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-7</b> : Click on \"Actions\"->\"Discard\" option from Actions dropdown of particular crime.");
		Assert.assertEquals("Are you sure?", driver.findElement(By.xpath(UserManagement_repository.validation_1stline)).getText());
		Assert.assertEquals("Are you sure you want to discard this record?", driver.findElement(By.xpath(UserManagement_repository.validation_2ndline)).getText());
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_1</b> : User should get validation message like : \r\n"
				+ "\"Are you sure?\r\n"
				+ "Are you sure you want to discard this record?\"."));
		ll.Screenshotnew(driver,i,method.getName()+"_01");
		driver.findElement(By.xpath(UserManagement_repository.validation_btn_yes)).click();
		Thread.sleep(3000);
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.validation_1stline)).isDisplayed(), false);
		ExtentTestManager.getTest().log(Status.INFO, "<b>Step-8</b> : Click on \"Yes\" button of validation message popup.");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.toast_msg)).getText(), "Successfully discarded!");
		Assert.assertEquals(driver.findElement(By.xpath(CrimeMapping_repository.text_nodataavailable)).isDisplayed(), true);
		ExtentTestManager.getTest().log(Status.INFO, String.format("<b>Result_2</b> : </br>1. User should able to click on \"Yes\" button of validation message popup and message popup should close.</br>"
				+ "2. User should get toast validation message like \" Successfully discarded!\".</br>"
				+ "3. Discarded record should removed from \"Crimes\" listing page."));
	}
	
	@AfterMethod
	public void Aftermethod() throws InterruptedException
	{
		/*
		Actions act=new Actions(driver);
		act.moveToElement(driver.findElement(By.xpath(Login_repository.profile_admin))).
		build().perform(); Thread.sleep(1000);
		driver.findElement(By.xpath(Login_repository.lnk_logout)).click();
		Thread.sleep(2000); 
		
		driver.close();
		Thread.sleep(1000);*/
	}
}